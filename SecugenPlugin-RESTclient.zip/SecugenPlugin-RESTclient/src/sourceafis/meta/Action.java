/**
 * @author Veaceslav Dubenco
 * @since 17.10.2012
 */
package sourceafis.meta;

/**
 * 
 */
public interface Action {
	public void function();
}
