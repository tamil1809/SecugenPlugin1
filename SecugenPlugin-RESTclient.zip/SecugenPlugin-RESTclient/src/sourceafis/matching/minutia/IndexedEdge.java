package sourceafis.matching.minutia;
/*
 * Added newly
 */
public final class IndexedEdge {
	public EdgeShape shape;
	public EdgeLocation location;
}