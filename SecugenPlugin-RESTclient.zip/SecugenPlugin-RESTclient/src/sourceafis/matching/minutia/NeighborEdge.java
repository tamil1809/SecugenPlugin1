package sourceafis.matching.minutia;


public class NeighborEdge
{
    public EdgeShape edge;
    public int neighbor;
}