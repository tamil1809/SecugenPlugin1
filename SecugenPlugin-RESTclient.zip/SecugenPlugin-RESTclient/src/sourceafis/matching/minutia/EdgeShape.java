package sourceafis.matching.minutia;
  public class EdgeShape
    {
        public short length;
        public byte referenceAngle;
        public byte neighborAngle;
    }