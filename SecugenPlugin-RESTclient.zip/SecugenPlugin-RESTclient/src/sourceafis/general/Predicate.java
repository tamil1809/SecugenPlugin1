package sourceafis.general;

public interface Predicate<T> {
	boolean apply(T input);
}
