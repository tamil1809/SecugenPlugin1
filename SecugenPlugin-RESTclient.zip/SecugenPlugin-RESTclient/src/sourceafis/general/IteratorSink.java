package sourceafis.general;

public interface IteratorSink<T> {
	boolean next(T value);
}
