package sourceafis.general;

public class PolarPoint {
	public int Distance;
	public byte Angle;

	public PolarPoint(int distance, byte angle) {
		Distance = distance;
		Angle = angle;
	}
}
