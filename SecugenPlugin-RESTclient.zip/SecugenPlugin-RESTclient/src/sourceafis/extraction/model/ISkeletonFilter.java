/**
 * @author Veaceslav Dubenco
 * @since 20.10.2012
 */
package sourceafis.extraction.model;

/**
 * 
 */
public interface ISkeletonFilter {
	void Filter(SkeletonBuilder skeleton);
}
